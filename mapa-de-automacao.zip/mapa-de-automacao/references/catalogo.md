# Catálogo de automações · sinais e exemplos

Use para dar exemplos durante a entrevista e para sugerir soluções no mapa. "Sinal" é o que a pessoa costuma dizer quando aquela automação faz sentido.

## Por área

### Atendimento
| Sinal | Automação | Opção simples | Opção com IA |
|---|---|---|---|
| "Respondo as mesmas perguntas o dia todo" | Respostas para perguntas frequentes | Respostas rápidas e mensagem de ausência no WhatsApp Business | Atendente de IA no WhatsApp que responde, qualifica e passa pra um humano |
| "Cliente manda mensagem de noite e só respondemos no outro dia" | Atendimento fora do horário | Mensagem automática com horário e link de pedido/agenda | IA que agenda, tira pedido ou coleta dados e deixa pronto pra equipe |
| "Cliente pergunta onde está o pedido" | Aviso de status | Mensagem automática a cada mudança de status no sistema | IA que consulta o sistema e responde na hora |

### Vendas
| Sinal | Automação | Opção simples | Opção com IA |
|---|---|---|---|
| "Esqueço de retornar orçamento" | Follow-up automático | Lembretes no CRM ou na planilha com data | Sequência de mensagens personalizadas por etapa |
| "Monto proposta copiando a anterior" | Geração de proposta | Modelo com campos preenchidos de um formulário | IA que escreve a proposta a partir da conversa com o cliente |
| "Leads chegam do anúncio e ninguém vê" | Lead direto no CRM com aviso | Integração do formulário do anúncio com CRM + aviso no WhatsApp do vendedor | IA que qualifica o lead antes de passar |
| "Não sei de onde vêm meus clientes" | Registro de origem | Campo obrigatório de origem no CRM | Relatório semanal automático por origem |

### Operação
| Sinal | Automação | Opção simples | Opção com IA |
|---|---|---|---|
| "Alguém passa pedido de um sistema pro outro" | Integração entre sistemas | Integração nativa ou conector (Zapier, Make, n8n) | IA lendo pedidos em PDF, e-mail ou foto |
| "Agenda confusa, faltas" | Agendamento e confirmação | Link de agendamento + lembrete automático 24 h antes | IA que remarca pelo WhatsApp |
| "Estoque acaba sem ninguém perceber" | Alerta de estoque mínimo | Regra na planilha/sistema com aviso | Previsão de reposição pelo histórico |
| "Relatório toma a sexta-feira inteira" | Relatório automático | Painel que se atualiza sozinho | IA que escreve o resumo da semana com os números |

### Financeiro
| Sinal | Automação | Opção simples | Opção com IA |
|---|---|---|---|
| "Cobro cliente um por um" | Régua de cobrança | Boleto/Pix com lembrete automático antes e depois do vencimento | Mensagens de cobrança que mudam o tom conforme o atraso e negociam dentro de regras |
| "Nota fiscal é manual" | Emissão automática | Emissão integrada ao sistema de vendas | — |
| "Conferir extrato leva horas" | Conciliação | Conciliação do banco/ERP | IA classificando lançamentos |

### Marketing e pós-venda
| Sinal | Automação | Opção simples | Opção com IA |
|---|---|---|---|
| "Não peço avaliação" | Pedido de avaliação | Mensagem automática X dias após a compra | — |
| "Cliente compra uma vez e some" | Reativação | Lista de clientes inativos + mensagem programada | Ofertas personalizadas pelo histórico |
| "Não tenho tempo de postar" | Calendário de conteúdo | Agendador de posts | IA gerando rascunhos a partir de um briefing |

### Gestão e equipe
| Sinal | Automação | Opção simples | Opção com IA |
|---|---|---|---|
| "A equipe me pergunta tudo" | Base de respostas internas | Documento único de processos | Assistente interno de IA treinado nos processos |
| "Contratação e onboarding bagunçados" | Fluxo de admissão | Checklist automático | — |

## Por setor (dores mais comuns)
- **Restaurante / delivery:** pedidos pelo WhatsApp, cardápio e horário perguntados o dia todo, confirmação de pedido, avaliação depois da entrega, estoque de insumos.
- **Varejo / loja:** dúvidas de preço e disponibilidade, reserva de produto, aviso de chegada, recompra, estoque mínimo.
- **Clínica / consultório / estética:** agendamento, confirmação e faltas, pré-consulta, retorno, pós-procedimento.
- **Escritório de advocacia / contabilidade:** cobrança de honorários, captação de documentos do cliente, andamento de processo, prazos, leads de anúncio direto no CRM.
- **Prestador de serviço / agência:** orçamento, proposta, contrato, onboarding do cliente, relatórios mensais.
- **Indústria / distribuição:** pedidos de representantes, conferência de pedidos, cobrança, previsão de estoque, relatório comercial.
- **Imobiliária / corretor:** captação e qualificação de leads, agendamento de visita, envio de imóveis parecidos.

## Ordem de grandeza (para checar se a conta faz sentido)
- 30 mensagens/dia × 2 min = ~20 h/mês só respondendo o repetido.
- 1 relatório semanal de 3 h = ~12 h/mês.
- Cobrança manual de 40 clientes × 5 min = ~3,5 h/mês, mais o dinheiro que atrasa.
Use só para conferir; o mapa sempre usa os números da pessoa.
